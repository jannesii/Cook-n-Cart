shiboken_library_soversion = str(6.8)

version = "6.8.0.2"
version_info = (6, 8, 0.2, "", "")

__build_date__ = '2024-10-23T15:08:16+00:00'




__setup_py_package_version__ = '6.8.0.2'

